#!/usr/bin/env python3
"""Demo: fetch Himawari BT data via the trial provider and render a grayscale PNG."""

from __future__ import annotations

import argparse
import datetime as dt
from pathlib import Path

import numpy as np
from PIL import Image

from trial_clouddisc.config import CloudDiscConfig
from trial_clouddisc.providers.hima import HimaProvider


def _parse_timeslot(value: str) -> dt.datetime:
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    parsed = dt.datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    else:
        parsed = parsed.astimezone(dt.timezone.utc)
    return parsed.replace(second=0, microsecond=0)


def _valid_bt_mask(bt: np.ndarray) -> np.ndarray:
    return np.isfinite(bt) & (bt > 0.0)


def _auto_bt_range(bt: np.ndarray, valid_mask: np.ndarray) -> tuple[float, float]:
    vals = bt[valid_mask].astype(np.float64)
    if vals.size == 0:
        raise ValueError("No valid BT pixels found for rendering")
    bt_warm = float(np.percentile(vals, 97.0))
    bt_cold = float(np.percentile(vals, 3.0))
    if bt_warm - bt_cold < 20.0:
        mid = 0.5 * (bt_warm + bt_cold)
        bt_cold = mid - 10.0
        bt_warm = mid + 10.0
    return bt_cold, bt_warm


def _render_grayscale_png(
    bt: np.ndarray,
    output_png: Path,
    *,
    bt_cold: float | None,
    bt_warm: float | None,
    gamma: float,
) -> tuple[float, float]:
    valid_mask = _valid_bt_mask(bt)
    if bt_cold is None or bt_warm is None:
        auto_cold, auto_warm = _auto_bt_range(bt, valid_mask)
        if bt_cold is None:
            bt_cold = auto_cold
        if bt_warm is None:
            bt_warm = auto_warm
    if bt_warm <= bt_cold + 1e-6:
        raise ValueError("bt_warm must be greater than bt_cold")
    if gamma <= 0.0:
        raise ValueError("gamma must be > 0")

    weight = np.zeros_like(bt, dtype=np.float32)
    weight[valid_mask] = (float(bt_warm) - bt[valid_mask]) / (float(bt_warm) - float(bt_cold))
    weight = np.clip(weight, 0.0, 1.0)
    if gamma != 1.0:
        weight[valid_mask] = np.power(weight[valid_mask], gamma, dtype=np.float32)

    luminance = np.zeros_like(bt, dtype=np.uint8)
    alpha = np.zeros_like(bt, dtype=np.uint8)
    luminance[valid_mask] = np.round(weight[valid_mask] * 255.0).astype(np.uint8)
    alpha[valid_mask] = 255

    img = Image.fromarray(np.dstack([luminance, alpha]), mode="LA")
    output_png.parent.mkdir(parents=True, exist_ok=True)
    img.save(output_png)
    return float(bt_cold), float(bt_warm)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timeslot-utc", type=_parse_timeslot, required=True, help="UTC timeslot like 2026-03-21T06:10:00Z")
    parser.add_argument("--output-png", type=Path, required=True, help="Output grayscale PNG path")
    parser.add_argument("--lat", type=float, help="Observer latitude for partial tile selection")
    parser.add_argument("--lon", type=float, help="Observer longitude for partial tile selection")
    parser.add_argument("--local-tile-dir", type=Path, help="Use an already cached local tile directory instead of S3 lookup")
    parser.add_argument("--cache-dir", type=Path, default=None, help="Optional cache directory root")
    parser.add_argument("--cloud-shell-km", type=float, default=6376.0, help="Cloud shell radius in km")
    parser.add_argument("--azimuth-samples", type=int, default=1440, help="Boundary sample count for partial tile selection")
    parser.add_argument("--margin-tiles", type=int, default=1, help="Extra tile ring for partial tile selection")
    parser.add_argument("--bt-cold", type=float, default=None, help="Brightness temperature mapped to white")
    parser.add_argument("--bt-warm", type=float, default=None, help="Brightness temperature mapped to black")
    parser.add_argument("--gamma", type=float, default=0.85, help="Gamma applied to cloud weight")
    args = parser.parse_args()

    if (args.lat is None) ^ (args.lon is None):
        raise SystemExit("--lat and --lon must be provided together")

    cfg = CloudDiscConfig(cache_dir=args.cache_dir)
    provider = HimaProvider(cfg)
    if args.local_tile_dir is not None:
        da, used_time, paths = provider.fetch_bt_c13_from_local_dir(
            args.local_tile_dir,
            used_time=args.timeslot_utc,
            observer_lat=args.lat,
            observer_lon=args.lon,
            cloud_shell_km=args.cloud_shell_km,
            azimuth_samples=args.azimuth_samples,
            margin_tiles=args.margin_tiles,
        )
    else:
        da, used_time, paths = provider.fetch_bt_c13(
            args.timeslot_utc,
            observer_lat=args.lat,
            observer_lon=args.lon,
            cloud_shell_km=args.cloud_shell_km,
            azimuth_samples=args.azimuth_samples,
            margin_tiles=args.margin_tiles,
        )
    bt = np.asarray(da.values, dtype=np.float32)
    bt_cold, bt_warm = _render_grayscale_png(
        bt,
        args.output_png,
        bt_cold=args.bt_cold,
        bt_warm=args.bt_warm,
        gamma=args.gamma,
    )

    print(f"used_time={used_time.isoformat()}")
    print(f"shape={da.shape}")
    print(f"source_paths={len(paths)}")
    print(f"has_area={'area' in da.attrs}")
    if args.local_tile_dir is not None:
        print(f"local_tile_dir={args.local_tile_dir}")
    if args.lat is not None and args.lon is not None:
        print(f"observer_lat={args.lat}")
        print(f"observer_lon={args.lon}")
    print(f"output_png={args.output_png}")
    print(f"bt_cold={bt_cold:.3f}")
    print(f"bt_warm={bt_warm:.3f}")
    print(f"gamma={args.gamma:.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
