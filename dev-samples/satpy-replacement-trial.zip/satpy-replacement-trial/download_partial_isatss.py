#!/usr/bin/env python3
"""Select and optionally download only the Himawari ISatSS tiles needed for an observer."""

from __future__ import annotations

import argparse
import datetime as dt
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import boto3
import numpy as np
import xarray as xr
from botocore import UNSIGNED
from botocore.config import Config
from pyproj import CRS, Transformer

from zstarview.clouddisc.projectors.az import altaz_to_dir_ecef, geodetic_to_ecef
from zstarview.clouddisc.providers._s3_io import download_s3_object, list_s3_keys


_RE_TILE = re.compile(r"-T(\d{3})_")
_HIMA_BUCKETS = ("noaa-himawari9", "noaa-himawari8")
_PREFIX_ROOT = "AHI-L2-FLDK-ISatSS"
_PRODUCT = "ISatSS-B13"
_SATELLITE = "HIMAWARI"


@dataclass(frozen=True)
class TemplateMeta:
    bucket: str
    tile_path: Path
    tile_height: int
    tile_width: int
    product_rows: int
    product_cols: int
    tile_count: int
    x0: float
    y0: float
    x_step: float
    y_step: float
    geos_scale: float
    crs: CRS


@dataclass(frozen=True)
class TileRecord:
    token: str
    row_offset: int
    col_offset: int
    x_min: float
    x_max: float
    y_min: float
    y_max: float


def _parse_timeslot(value: str) -> dt.datetime:
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    parsed = dt.datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    else:
        parsed = parsed.astimezone(dt.timezone.utc)
    return parsed.replace(second=0, microsecond=0)


def _format_prefix(when_utc: dt.datetime) -> str:
    slot = when_utc.astimezone(dt.timezone.utc)
    hm = f"{slot.hour:02d}{(slot.minute // 10) * 10:02d}"
    return f"{_PREFIX_ROOT}/{slot.year:04d}/{slot.month:02d}/{slot.day:02d}/{hm}/"


def _make_s3():
    return boto3.client(
        "s3",
        config=Config(signature_version=UNSIGNED, retries={"max_attempts": 1}, connect_timeout=5.0, read_timeout=30.0),
    )


def _extract_tile_token(name: str) -> str:
    match = _RE_TILE.search(name)
    if not match:
        raise ValueError(f"Could not extract tile token from {name}")
    return match.group(1)


def _find_matching_keys(s3_client, when_utc: dt.datetime) -> tuple[str, list[str]]:
    prefix = _format_prefix(when_utc)
    for bucket in _HIMA_BUCKETS:
        keys = list_s3_keys(
            s3_client=s3_client,
            bucket=bucket,
            prefix=prefix,
            satellite=_SATELLITE,
            product=_PRODUCT,
            time_utc=when_utc,
        )
        matched = sorted(key for key in keys if "M1C13" in Path(key).name and key.endswith(".nc"))
        if matched:
            return bucket, matched
    raise FileNotFoundError(f"No Himawari ISatSS M1C13 keys found for {_format_prefix(when_utc)}")


def _load_template_from_tile(tile_path: Path, bucket: str) -> TemplateMeta:
    ds = xr.open_dataset(tile_path)
    try:
        tile_height = int(ds.sizes["y"])
        tile_width = int(ds.sizes["x"])
        product_rows = int(ds.attrs["product_rows"])
        product_cols = int(ds.attrs["product_columns"])
        tile_count = int(ds.attrs["number_product_tiles"])
        x_step = float(ds.x.values[1] - ds.x.values[0])
        y_step = float(ds.y.values[1] - ds.y.values[0])
        x0 = float(ds.x.values[0] - int(ds.attrs["tile_column_offset"]) * x_step)
        y0 = float(ds.y.values[0] - int(ds.attrs["tile_row_offset"]) * y_step)
        crs = CRS.from_cf(dict(ds["fixedgrid_projection"].attrs))
        geos_scale = float(ds["fixedgrid_projection"].attrs["perspective_point_height"]) * 1e-6
        return TemplateMeta(
            bucket=bucket,
            tile_path=tile_path,
            tile_height=tile_height,
            tile_width=tile_width,
            product_rows=product_rows,
            product_cols=product_cols,
            tile_count=tile_count,
            x0=x0,
            y0=y0,
            x_step=x_step,
            y_step=y_step,
            geos_scale=geos_scale,
            crs=crs,
        )
    finally:
        ds.close()


def _load_template_from_local_dir(tile_dir: Path) -> TemplateMeta:
    first = sorted(tile_dir.glob("*M1C13*.nc"))[0]
    return _load_template_from_tile(first, bucket="local")


def _download_template_tile(s3_client, bucket: str, key: str, cache_root: Path, when_utc: dt.datetime) -> Path:
    return download_s3_object(
        s3_client=s3_client,
        bucket=bucket,
        key=key,
        dst=cache_root / bucket / key,
        satellite=_SATELLITE,
        product=_PRODUCT,
        time_utc=when_utc,
    )


def _generate_sparse_layout(meta: TemplateMeta) -> list[TileRecord]:
    grid_rows = meta.product_rows // meta.tile_height
    grid_cols = meta.product_cols // meta.tile_width
    if meta.product_rows % meta.tile_height or meta.product_cols % meta.tile_width:
        raise ValueError("Product size is not divisible by tile size")

    if meta.tile_count == grid_rows * grid_cols:
        row_counts = [grid_cols] * grid_rows
    elif grid_rows == 10 and grid_cols == 10 and meta.tile_count == 88:
        row_counts = [6, 8, 10, 10, 10, 10, 10, 10, 8, 6]
    else:
        raise ValueError(
            f"Unsupported sparse tile layout: grid={grid_rows}x{grid_cols}, tile_count={meta.tile_count}"
        )

    if sum(row_counts) != meta.tile_count:
        raise ValueError(f"Tile layout mismatch: expected {meta.tile_count}, got {sum(row_counts)}")

    records: list[TileRecord] = []
    token = 1
    for row_index, count in enumerate(row_counts):
        start_col = (grid_cols - count) // 2
        for local_col in range(count):
            row_offset = row_index * meta.tile_height
            col_offset = (start_col + local_col) * meta.tile_width
            x_a = meta.x0 + col_offset * meta.x_step
            x_b = meta.x0 + (col_offset + meta.tile_width) * meta.x_step
            y_a = meta.y0 + row_offset * meta.y_step
            y_b = meta.y0 + (row_offset + meta.tile_height) * meta.y_step
            records.append(
                TileRecord(
                    token=f"{token:03d}",
                    row_offset=row_offset,
                    col_offset=col_offset,
                    x_min=min(x_a, x_b) * meta.geos_scale,
                    x_max=max(x_a, x_b) * meta.geos_scale,
                    y_min=min(y_a, y_b) * meta.geos_scale,
                    y_max=max(y_a, y_b) * meta.geos_scale,
                )
            )
            token += 1
    return records


def _intersect_cloud_shell(observer_xyz: np.ndarray, direction_xyz: np.ndarray, shell_radius_km: float) -> tuple[float, float, float] | None:
    b_quad = 2.0 * float(np.dot(observer_xyz, direction_xyz))
    c_quad = float(np.dot(observer_xyz, observer_xyz) - shell_radius_km * shell_radius_km)
    disc = b_quad * b_quad - 4.0 * c_quad
    if disc < 0.0:
        return None
    sqrt_disc = math.sqrt(max(disc, 0.0))
    t1 = (-b_quad - sqrt_disc) / 2.0
    t2 = (-b_quad + sqrt_disc) / 2.0
    t = t1 if t1 > 1e-6 else (t2 if t2 > 1e-6 else None)
    if t is None:
        return None
    point = observer_xyz + direction_xyz * t
    return float(point[0]), float(point[1]), float(point[2])


def _visible_boundary_lonlat(
    *,
    lat_deg: float,
    lon_deg: float,
    alt_min_deg: float,
    cloud_shell_km: float,
    azimuth_samples: int,
) -> tuple[np.ndarray, np.ndarray]:
    observer_xyz = np.asarray(geodetic_to_ecef(lat_deg, lon_deg), dtype=np.float64)
    lons: list[float] = [float(lon_deg)]
    lats: list[float] = [float(lat_deg)]
    for az_deg in np.linspace(0.0, 360.0, azimuth_samples, endpoint=False):
        direction = np.asarray(altaz_to_dir_ecef(alt_min_deg, float(az_deg), lat_deg, lon_deg), dtype=np.float64)
        hit = _intersect_cloud_shell(observer_xyz, direction, cloud_shell_km)
        if hit is None:
            continue
        x, y, z = hit
        lons.append(math.degrees(math.atan2(y, x)))
        lats.append(math.degrees(math.atan2(z, math.hypot(x, y))))
    return np.asarray(lons, dtype=np.float64), np.asarray(lats, dtype=np.float64)


def _point_in_polygon(x: float, y: float, poly_x: np.ndarray, poly_y: np.ndarray) -> bool:
    inside = False
    n = poly_x.size
    j = n - 1
    for i in range(n):
        yi, yj = poly_y[i], poly_y[j]
        xi, xj = poly_x[i], poly_x[j]
        intersects = ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi)
        if intersects:
            inside = not inside
        j = i
    return inside


def _tile_intersects_polygon(tile: TileRecord, poly_x: np.ndarray, poly_y: np.ndarray) -> bool:
    if poly_x.size == 0:
        return False
    if poly_x.max() < tile.x_min or poly_x.min() > tile.x_max or poly_y.max() < tile.y_min or poly_y.min() > tile.y_max:
        return False

    center = ((tile.x_min + tile.x_max) * 0.5, (tile.y_min + tile.y_max) * 0.5)
    if _point_in_polygon(center[0], center[1], poly_x, poly_y):
        return True

    corners = [
        (tile.x_min, tile.y_min),
        (tile.x_min, tile.y_max),
        (tile.x_max, tile.y_min),
        (tile.x_max, tile.y_max),
    ]
    if any(_point_in_polygon(x, y, poly_x, poly_y) for x, y in corners):
        return True

    boundary_hit = (
        (poly_x >= tile.x_min)
        & (poly_x <= tile.x_max)
        & (poly_y >= tile.y_min)
        & (poly_y <= tile.y_max)
    )
    return bool(np.any(boundary_hit))


def _expand_selection(tokens: set[str], records: list[TileRecord], margin_tiles: int) -> set[str]:
    if margin_tiles <= 0:
        return tokens
    by_token = {record.token: record for record in records}
    selected = set(tokens)
    row_stride = min(
        abs(a.row_offset - b.row_offset)
        for a in records
        for b in records
        if a.row_offset != b.row_offset
    )
    col_stride = min(
        abs(a.col_offset - b.col_offset)
        for a in records
        for b in records
        if a.col_offset != b.col_offset
    )
    for _ in range(margin_tiles):
        grown = set(selected)
        for token in list(selected):
            record = by_token[token]
            for other in records:
                if abs(other.row_offset - record.row_offset) <= row_stride and abs(other.col_offset - record.col_offset) <= col_stride:
                    grown.add(other.token)
        selected = grown
    return selected


def select_needed_tiles(
    *,
    lat_deg: float,
    lon_deg: float,
    meta: TemplateMeta,
    cloud_shell_km: float,
    azimuth_samples: int,
    margin_tiles: int,
) -> tuple[list[TileRecord], np.ndarray, np.ndarray]:
    lons, lats = _visible_boundary_lonlat(
        lat_deg=lat_deg,
        lon_deg=lon_deg,
        alt_min_deg=0.0,
        cloud_shell_km=cloud_shell_km,
        azimuth_samples=azimuth_samples,
    )
    to_proj = Transformer.from_crs("EPSG:4326", meta.crs, always_xy=True)
    poly_x, poly_y = to_proj.transform(lons, lats)
    finite = np.isfinite(poly_x) & np.isfinite(poly_y)
    poly_x = np.asarray(poly_x[finite], dtype=np.float64)
    poly_y = np.asarray(poly_y[finite], dtype=np.float64)
    records = _generate_sparse_layout(meta)
    selected_tokens = {record.token for record in records if _tile_intersects_polygon(record, poly_x, poly_y)}
    selected_tokens = _expand_selection(selected_tokens, records, margin_tiles)
    selected = [record for record in records if record.token in selected_tokens]
    selected.sort(key=lambda item: item.token)
    return selected, poly_x, poly_y


def _download_selected_keys(
    *,
    s3_client,
    bucket: str,
    keys: Iterable[str],
    cache_root: Path,
    when_utc: dt.datetime,
) -> list[Path]:
    paths: list[Path] = []
    for key in keys:
        paths.append(
            download_s3_object(
                s3_client=s3_client,
                bucket=bucket,
                key=key,
                dst=cache_root / bucket / key,
                satellite=_SATELLITE,
                product=_PRODUCT,
                time_utc=when_utc,
            )
        )
    return paths


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lat", type=float, required=True, help="Observer latitude in degrees")
    parser.add_argument("--lon", type=float, required=True, help="Observer longitude in degrees")
    parser.add_argument("--timeslot-utc", type=_parse_timeslot, help="UTC timeslot like 2026-03-21T06:10:00Z")
    parser.add_argument("--cloud-shell-km", type=float, default=6376.0, help="Cloud shell radius in km")
    parser.add_argument("--azimuth-samples", type=int, default=1440, help="Boundary sample count around the observer")
    parser.add_argument("--margin-tiles", type=int, default=1, help="Extra tile ring to keep around the selected set")
    parser.add_argument("--cache-root", type=Path, default=Path.home() / ".cache" / "zstarview" / "hima_isatss", help="Cache root for downloaded tiles")
    parser.add_argument("--local-tile-dir", type=Path, help="Use a local cached tile directory instead of S3")
    parser.add_argument("--dry-run", action="store_true", help="Only print selected tile tokens and keys")
    args = parser.parse_args()

    if args.local_tile_dir is None and args.timeslot_utc is None:
        raise SystemExit("--timeslot-utc is required unless --local-tile-dir is used")

    if args.local_tile_dir is not None:
        meta = _load_template_from_local_dir(args.local_tile_dir)
        selected, poly_x, poly_y = select_needed_tiles(
            lat_deg=args.lat,
            lon_deg=args.lon,
            meta=meta,
            cloud_shell_km=args.cloud_shell_km,
            azimuth_samples=args.azimuth_samples,
            margin_tiles=args.margin_tiles,
        )
        local_paths = sorted(args.local_tile_dir.glob("*M1C13*.nc"))
        selected_set = {record.token for record in selected}
        kept = [path for path in local_paths if _extract_tile_token(path.name) in selected_set]
        print(f"local_tile_dir={args.local_tile_dir}")
        print(f"selected_tiles={len(selected)}")
        print("tokens=" + ",".join(record.token for record in selected))
        print(f"projected_boundary_points={poly_x.size}")
        for path in kept:
            print(path)
        return 0

    when_utc = args.timeslot_utc
    assert when_utc is not None
    s3_client = _make_s3()
    bucket, keys = _find_matching_keys(s3_client, when_utc)
    template_path = _download_template_tile(s3_client, bucket, keys[0], args.cache_root, when_utc)
    meta = _load_template_from_tile(template_path, bucket=bucket)
    selected, poly_x, poly_y = select_needed_tiles(
        lat_deg=args.lat,
        lon_deg=args.lon,
        meta=meta,
        cloud_shell_km=args.cloud_shell_km,
        azimuth_samples=args.azimuth_samples,
        margin_tiles=args.margin_tiles,
    )
    selected_tokens = {record.token for record in selected}
    key_map = {_extract_tile_token(Path(key).name): key for key in keys}
    selected_keys = [key_map[token] for token in sorted(selected_tokens) if token in key_map]

    print(f"bucket={bucket}")
    print(f"timeslot_utc={when_utc.isoformat()}")
    print(f"selected_tiles={len(selected_keys)} / {len(keys)}")
    print("tokens=" + ",".join(sorted(selected_tokens)))
    print(f"projected_boundary_points={poly_x.size}")
    if args.dry_run:
        for key in selected_keys:
            print(f"s3://{bucket}/{key}")
        return 0

    paths = _download_selected_keys(
        s3_client=s3_client,
        bucket=bucket,
        keys=selected_keys,
        cache_root=args.cache_root,
        when_utc=when_utc,
    )
    for path in paths:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
