# zstarview Handoff

## Purpose

This document summarizes what was validated in `satpy-replacement-trial` and
what should be migrated back into the parent `zstarview` project.

The parent project was intentionally left unchanged during this session.

## What Was Confirmed

### 1. Himawari ISatSS `M1C13` tiles are usable without Satpy

- Product path pattern:
  - `AHI-L2-FLDK-ISatSS/YYYY/MM/DD/HHMM/`
- Relevant files are named with `M1C13`, not plain `B13`.
- A full timeslot currently appears as `88` NetCDF tiles.
- Each tile contains:
  - data variable: `Sectorized_CMI`
  - grid mapping: `fixedgrid_projection`
- `Sectorized_CMI` reports:
  - `standard_name=brightness_temperature`
  - `units=kelvin`

### 2. Tiles can be stitched directly with `xarray`

- Tile size: `550 x 550`
- Declared product size: `5500 x 5500`
- Layout: sparse `10 x 10` tile grid with `88` populated cells
- Missing cells are the outer corners; no unexpected gaps or overlaps were found
- A stitched `xarray.Dataset` was produced successfully

### 3. `da.attrs["area"]` can be rebuilt without Satpy

- `fixedgrid_projection` contains enough CF geostationary metadata
- A `pyresample.geometry.AreaDefinition` can be built directly
- `zstarview.clouddisc.sampling.bt_sampler` worked with this rebuilt `area`
- Round-trip verification against representative pixels returned zero error

### 4. Partial tile download is viable

- For observer-based cloud rendering, downloading all `88` tiles is often unnecessary
- A prototype selector was built that:
  - projects the observer-visible horizon footprint onto the cloud shell
  - transforms that footprint into Himawari geostationary coordinates
  - keeps only intersecting tiles plus a configurable margin
- For the Matsue-area test case:
  - observer: `lat=35.47`, `lon=133.05`
  - timeslot: `2026-03-21T06:10:00Z`
  - selected tiles: `9 / 88`
  - tokens: `002,003,004,009,010,011,018,019,020`

### 5. End-to-end provider path works in trial form

- A copied trial provider package was created under `src/trial_clouddisc/`
- Trial `HimaProvider` now:
  - lists S3 keys
  - selects observer-relevant tiles
  - downloads only those tiles
  - stitches them
  - attaches `area`
  - returns a float32 `xarray.DataArray`
- End-to-end PNG generation from that provider succeeded

## Files To Review In This Trial

### Core prototypes

- [download_partial_isatss.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/download_partial_isatss.py)
- [stitch_isatss_tiles.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/stitch_isatss_tiles.py)
- [render_isatss_grayscale_png.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/render_isatss_grayscale_png.py)
- [demo_trial_hima_provider.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/demo_trial_hima_provider.py)

### Trial package intended as migration reference

- [src/trial_clouddisc/config.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/src/trial_clouddisc/config.py)
- [src/trial_clouddisc/types.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/src/trial_clouddisc/types.py)
- [src/trial_clouddisc/providers/_s3_io.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/src/trial_clouddisc/providers/_s3_io.py)
- [src/trial_clouddisc/providers/hima.py](/home/toshihiro/playground/zstarview/satpy-replacement-trial/src/trial_clouddisc/providers/hima.py)

## What Should Move To zstarview

### Keep in zstarview

- GOES/HIMAWARI selection logic
- overall cloud pipeline orchestration
- existing `CloudDisc` flow and public interfaces

### Replace inside zstarview

Replace the current Satpy-based Himawari implementation in
[hima.py](/home/toshihiro/playground/zstarview/src/zstarview/clouddisc/providers/hima.py)
with logic based on the trial provider.

That replacement should:

1. List `M1C13` keys under the target ISatSS prefix.
2. Optionally reduce the key set to observer-relevant tiles.
3. Download only the selected keys.
4. Stitch the tiles with `xarray`.
5. Attach a rebuilt `area` object to the returned `DataArray`.
6. Return the stitched BT field to the existing `CloudDisc` pipeline.

## Recommended Migration Order

1. Copy the direct-stitch logic into a private helper inside `zstarview`.
2. Replace only the internals of `HimaProvider.fetch_bt_c13()`.
3. Keep provider selection and `CloudDisc` call flow unchanged.
4. First land full-tile stitching if you want the smallest behavioral change.
5. Then enable observer-based partial tile selection as a follow-up or behind a flag.

## Recommended Minimum Tests In zstarview

1. A unit test that builds `area` from stitched ISatSS metadata and verifies
   the expected shape and CRS.
2. A unit test that checks the sparse `88`-tile layout stitches into a
   `5500 x 5500` field without overlap.
3. A provider-level test using cached local tiles that confirms:
   - returned object is an `xarray.DataArray`
   - dtype is float32
   - `area` exists in `attrs`
4. A partial-selection test for a fixed observer that confirms fewer than `88`
   tiles are selected.

## Important Assumptions And Caveats

- Current partial tile selection assumes the observed `88`-tile sparse layout
  inside a `10 x 10` tile grid.
- Current footprint selection uses the same cloud-shell radius as the current
  renderer: `Earth + 5 km` (`6376 km`).
- For tile selection against the geostationary CRS, tile extents must use:
  - `x/y [microradian] * perspective_point_height * 1e-6`
- For `bt_sampler` compatibility, `area_extent` must be built from pixel-center
  origin math, not half-pixel outer edges.
- In current tests, using `alt=0°` for partial download was sufficient; keeping
  an `alt_min_deg` parameter in the downloader did not improve tile selection.

## Suggested First Parent-Repo Task

Implement a local-only migration first:

1. Copy the trial `HimaProvider` logic into a branch in the parent repo.
2. Add a temporary path that loads from cached local ISatSS tiles.
3. Verify the returned `DataArray` works with `bt_sampler`.
4. Only after that, switch the production path from Satpy to direct S3 tile
   stitching.

## Session Artifacts

- Trial session notes:
  - [dev-notes/session-2026-03-21.md](/home/toshihiro/playground/zstarview/satpy-replacement-trial/dev-notes/session-2026-03-21.md)
- Example outputs:
  - [outputs/himawari_isatss_2026-03-21_0610_native.png](/home/toshihiro/playground/zstarview/satpy-replacement-trial/outputs/himawari_isatss_2026-03-21_0610_native.png)
  - [outputs/himawari_isatss_2026-03-21_0610_matsue_partial.png](/home/toshihiro/playground/zstarview/satpy-replacement-trial/outputs/himawari_isatss_2026-03-21_0610_matsue_partial.png)
  - [outputs/demo_trial_hima_provider_matsue.png](/home/toshihiro/playground/zstarview/satpy-replacement-trial/outputs/demo_trial_hima_provider_matsue.png)
  - [outputs/demo_trial_hima_provider_matsue_s3.png](/home/toshihiro/playground/zstarview/satpy-replacement-trial/outputs/demo_trial_hima_provider_matsue_s3.png)
