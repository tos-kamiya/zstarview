#!/usr/bin/env python3
"""Render stitched Himawari ISatSS M1C13 data to a grayscale PNG."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from PIL import Image

from stitch_isatss_tiles import DATA_VAR, _select_tile_paths_for_observer, stitch_tiles, stitch_tiles_from_paths


def _valid_bt_mask(bt: np.ndarray, coverage_mask: np.ndarray) -> np.ndarray:
    """Return a mask of physically plausible brightness temperatures."""
    return coverage_mask.astype(bool) & np.isfinite(bt) & (bt > 0.0)


def _auto_bt_range(bt: np.ndarray, valid_mask: np.ndarray) -> tuple[float, float]:
    vals = bt[valid_mask].astype(np.float64)
    if vals.size == 0:
        raise ValueError("No valid BT pixels found for rendering")
    bt_warm = float(np.percentile(vals, 97.0))
    bt_cold = float(np.percentile(vals, 3.0))
    if bt_warm - bt_cold < 20.0:
        mid = 0.5 * (bt_warm + bt_cold)
        bt_cold = mid - 10.0
        bt_warm = mid + 10.0
    return bt_cold, bt_warm


def render_png(
    tile_dir: Path,
    output_png: Path,
    *,
    bt_cold: float | None,
    bt_warm: float | None,
    gamma: float,
    observer_lat: float | None,
    observer_lon: float | None,
    cloud_shell_km: float,
    azimuth_samples: int,
    margin_tiles: int,
) -> tuple[float, float]:
    if observer_lat is None and observer_lon is None:
        ds = stitch_tiles(tile_dir)
    elif observer_lat is not None and observer_lon is not None:
        tile_paths = _select_tile_paths_for_observer(
            tile_dir,
            observer_lat=float(observer_lat),
            observer_lon=float(observer_lon),
            cloud_shell_km=float(cloud_shell_km),
            azimuth_samples=int(azimuth_samples),
            margin_tiles=int(margin_tiles),
        )
        ds = stitch_tiles_from_paths(
            tile_paths,
            source_label=f"{tile_dir} [observer lat={observer_lat}, lon={observer_lon}]",
        )
    else:
        raise ValueError("observer_lat and observer_lon must be provided together")
    try:
        bt = np.asarray(ds[DATA_VAR].values, dtype=np.float32)
        coverage_mask = np.asarray(ds["tile_coverage_mask"].values, dtype=bool)
        valid_mask = _valid_bt_mask(bt, coverage_mask)
        if bt_cold is None or bt_warm is None:
            auto_cold, auto_warm = _auto_bt_range(bt, valid_mask)
            if bt_cold is None:
                bt_cold = auto_cold
            if bt_warm is None:
                bt_warm = auto_warm
        if bt_warm <= bt_cold + 1e-6:
            raise ValueError("bt_warm must be greater than bt_cold")

        weight = np.zeros_like(bt, dtype=np.float32)
        weight[valid_mask] = (float(bt_warm) - bt[valid_mask]) / (float(bt_warm) - float(bt_cold))
        weight = np.clip(weight, 0.0, 1.0)
        if gamma <= 0.0:
            raise ValueError("gamma must be > 0")
        if gamma != 1.0:
            weight[valid_mask] = np.power(weight[valid_mask], gamma, dtype=np.float32)

        luminance = np.zeros_like(bt, dtype=np.uint8)
        alpha = np.zeros_like(bt, dtype=np.uint8)
        luminance[valid_mask] = np.round(weight[valid_mask] * 255.0).astype(np.uint8)
        alpha[valid_mask] = 255

        img = Image.fromarray(np.dstack([luminance, alpha]), mode="LA")
        output_png.parent.mkdir(parents=True, exist_ok=True)
        img.save(output_png)
        return float(bt_cold), float(bt_warm)
    finally:
        ds.close()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tile_dir", type=Path, help="Directory containing Himawari ISatSS M1C13 tile NetCDF files")
    parser.add_argument("output_png", type=Path, help="Output grayscale PNG path")
    parser.add_argument("--bt-cold", type=float, default=None, help="Brightness temperature mapped to white")
    parser.add_argument("--bt-warm", type=float, default=None, help="Brightness temperature mapped to black")
    parser.add_argument("--gamma", type=float, default=0.85, help="Gamma applied to cloud weight (default: 0.85)")
    parser.add_argument("--observer-lat", type=float, help="If set with --observer-lon, render only the locally selected tiles needed for this observer")
    parser.add_argument("--observer-lon", type=float, help="If set with --observer-lat, render only the locally selected tiles needed for this observer")
    parser.add_argument("--cloud-shell-km", type=float, default=6376.0, help="Cloud shell radius in km for observer-based tile selection")
    parser.add_argument("--azimuth-samples", type=int, default=1440, help="Boundary sample count for observer-based tile selection")
    parser.add_argument("--margin-tiles", type=int, default=1, help="Extra tile ring for observer-based tile selection")
    args = parser.parse_args()

    bt_cold, bt_warm = render_png(
        args.tile_dir,
        args.output_png,
        bt_cold=args.bt_cold,
        bt_warm=args.bt_warm,
        gamma=args.gamma,
        observer_lat=args.observer_lat,
        observer_lon=args.observer_lon,
        cloud_shell_km=args.cloud_shell_km,
        azimuth_samples=args.azimuth_samples,
        margin_tiles=args.margin_tiles,
    )
    print(f"tile_dir={args.tile_dir}")
    print(f"output_png={args.output_png}")
    if args.observer_lat is not None and args.observer_lon is not None:
        print(f"observer_lat={args.observer_lat}")
        print(f"observer_lon={args.observer_lon}")
    print(f"bt_cold={bt_cold:.3f}")
    print(f"bt_warm={bt_warm:.3f}")
    print(f"gamma={args.gamma:.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
