# satpy-replacement-trial

Trial workspace for investigating a `satpy` replacement path focused on
Himawari ISatSS ingestion.

## Goal

Build a minimal prototype that can read Himawari ISatSS `M1C13` tiles and
produce a merged `xarray.DataArray` that can eventually feed zstarview's cloud
pipeline without depending on `satpy` for this path.

## Scope for the next Codex session

1. Inspect one downloaded ISatSS tile with `xarray`.
2. Identify the temperature/radiance variable, dimensions, and global attrs.
3. Understand how tile indices map to a stitched full image.
4. Determine whether projection metadata is sufficient to replace
   `da.attrs["area"]` expected by zstarview.
5. Measure the rough cost of opening and stitching one timeslot.

## Non-goals for now

- Do not integrate a new reader into zstarview yet.
- Do not remove `satpy` from the main project yet.
- Do not optimize download/update cadence yet.

See `HANDOFF.md` for concrete findings and suggested next commands.
