#!/usr/bin/env python3
"""Stitch Himawari ISatSS M1C13 tiles into one xarray Dataset."""

from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Iterable

import numpy as np
import xarray as xr
from pyproj import CRS, Transformer
from pyresample.geometry import AreaDefinition

from download_partial_isatss import _load_template_from_local_dir, select_needed_tiles


DATA_VAR = "Sectorized_CMI"
GRID_VAR = "fixedgrid_projection"


def _iter_tile_paths(tile_dir: Path) -> list[Path]:
    paths = sorted(tile_dir.glob("*M1C13*.nc"))
    if not paths:
        raise FileNotFoundError(f"No *M1C13*.nc tiles found in {tile_dir}")
    return paths


def _select_tile_paths_for_observer(
    tile_dir: Path,
    *,
    observer_lat: float,
    observer_lon: float,
    cloud_shell_km: float,
    azimuth_samples: int,
    margin_tiles: int,
) -> list[Path]:
    meta = _load_template_from_local_dir(tile_dir)
    selected, _poly_x, _poly_y = select_needed_tiles(
        lat_deg=observer_lat,
        lon_deg=observer_lon,
        meta=meta,
        cloud_shell_km=cloud_shell_km,
        azimuth_samples=azimuth_samples,
        margin_tiles=margin_tiles,
    )
    selected_tokens = {record.token for record in selected}
    paths = [path for path in _iter_tile_paths(tile_dir) if any(f"-T{token}_" in path.name for token in selected_tokens)]
    if not paths:
        raise ValueError("Observer-based tile selection returned no local tiles")
    return paths


def _validate_same(values: Iterable[object], *, name: str) -> object:
    seq = list(values)
    first = seq[0]
    for value in seq[1:]:
        if value != first:
            raise ValueError(f"Inconsistent {name}: {first!r} != {value!r}")
    return first


def stitch_tiles_from_paths(paths: list[Path], *, source_label: str | None = None) -> xr.Dataset:
    if not paths:
        raise ValueError("No tile paths provided")
    datasets = [xr.open_dataset(path) for path in paths]
    try:
        first = datasets[0]
        tile_height = int(first.sizes["y"])
        tile_width = int(first.sizes["x"])
        product_rows = int(_validate_same((int(ds.attrs["product_rows"]) for ds in datasets), name="product_rows"))
        product_cols = int(_validate_same((int(ds.attrs["product_columns"]) for ds in datasets), name="product_columns"))
        channel_id = int(_validate_same((int(ds.attrs["channel_id"]) for ds in datasets), name="channel_id"))
        x_step = float(first.x.values[1] - first.x.values[0])
        y_step = float(first.y.values[1] - first.y.values[0])
        x0 = float(first.x.values[0] - int(first.attrs["tile_column_offset"]) * x_step)
        y0 = float(first.y.values[0] - int(first.attrs["tile_row_offset"]) * y_step)

        full = np.full((product_rows, product_cols), np.nan, dtype=np.float32)
        coverage = np.zeros((product_rows, product_cols), dtype=np.uint8)

        for path, ds in zip(paths, datasets):
            row0 = int(ds.attrs["tile_row_offset"])
            col0 = int(ds.attrs["tile_column_offset"])
            row1 = row0 + tile_height
            col1 = col0 + tile_width
            tile = np.asarray(ds[DATA_VAR].values, dtype=np.float32)
            if full[row0:row1, col0:col1].shape != tile.shape:
                raise ValueError(f"Tile shape mismatch for {path.name}")
            if np.any(coverage[row0:row1, col0:col1]):
                raise ValueError(f"Tile overlap detected for {path.name}")
            expected_x0 = x0 + col0 * x_step
            expected_y0 = y0 + row0 * y_step
            if not math.isclose(float(ds.x.values[0]), expected_x0, rel_tol=0.0, abs_tol=1e-6):
                raise ValueError(f"x coordinate mismatch for {path.name}")
            if not math.isclose(float(ds.y.values[0]), expected_y0, rel_tol=0.0, abs_tol=1e-6):
                raise ValueError(f"y coordinate mismatch for {path.name}")
            full[row0:row1, col0:col1] = tile
            coverage[row0:row1, col0:col1] = 1

        x = x0 + np.arange(product_cols, dtype=np.float64) * x_step
        y = y0 + np.arange(product_rows, dtype=np.float64) * y_step
        attrs = dict(first[DATA_VAR].attrs)
        attrs.update(
            {
                "source_tile_count": len(paths),
                "source_tile_dir": source_label or str(paths[0].parent),
                "channel_id": channel_id,
                "coverage_fraction": float(coverage.mean()),
            }
        )

        data = xr.DataArray(full, dims=("y", "x"), coords={"y": y, "x": x}, name=DATA_VAR, attrs=attrs)
        projection = first[GRID_VAR].copy(deep=True)
        merged = xr.Dataset(
            data_vars={DATA_VAR: data, GRID_VAR: projection, "tile_coverage_mask": (("y", "x"), coverage)},
            coords={"y": y, "x": x},
            attrs=dict(first.attrs),
        )
        merged.attrs.update(
            {
                "stitched_from_tiles": len(paths),
                "stitched_tile_height": tile_height,
                "stitched_tile_width": tile_width,
            }
        )
        return merged
    finally:
        for ds in datasets:
            ds.close()


def stitch_tiles(tile_dir: Path) -> xr.Dataset:
    return stitch_tiles_from_paths(_iter_tile_paths(tile_dir), source_label=str(tile_dir))


def build_area_from_dataset(ds: xr.Dataset) -> AreaDefinition:
    """Build a pyresample AreaDefinition compatible with zstarview.bt_sampler."""
    proj_var = ds[GRID_VAR]
    crs = CRS.from_cf(dict(proj_var.attrs))
    x = np.asarray(ds.x.values, dtype=np.float64)
    y = np.asarray(ds.y.values, dtype=np.float64)
    if x.ndim != 1 or y.ndim != 1 or x.size < 2 or y.size < 2:
        raise ValueError("Expected 1-D x/y coordinates with at least 2 points each")
    x_step = float(x[1] - x[0])
    y_step = float(y[1] - y[0])
    # zstarview.bt_sampler converts projected coordinates to floating pixel indices
    # as ``(x - min_x) / pixel_size`` and expects pixel centers to land on integer
    # indices. Therefore use center-origin extents instead of outer pixel edges.
    area_extent = (
        float(x[0]),
        float(y[0] + y.size * y_step),
        float(x[0] + x.size * x_step),
        float(y[0]),
    )
    return AreaDefinition(
        area_id="himawari_isatss_m1c13",
        description="Himawari ISatSS stitched M1C13",
        proj_id="geos",
        projection=crs,
        width=int(x.size),
        height=int(y.size),
        area_extent=area_extent,
    )


def attach_area_to_dataset(ds: xr.Dataset) -> xr.Dataset:
    """Return a copy of the dataset with Satpy-like ``area`` metadata attached."""
    area = build_area_from_dataset(ds)
    out = ds.copy(deep=False)
    da = out[DATA_VAR].copy(deep=False)
    attrs = dict(da.attrs)
    attrs["area"] = area
    da.attrs = attrs
    out[DATA_VAR] = da
    out.attrs = dict(out.attrs)
    out.attrs["area_id"] = area.area_id
    return out


def verify_sampler_roundtrip(ds: xr.Dataset) -> tuple[float, float]:
    """Verify that zstarview's sampler can round-trip a few pixel centers."""
    from zstarview.clouddisc.sampling.bt_sampler import build_bt_sampler

    prepared = attach_area_to_dataset(ds)
    da = prepared[DATA_VAR]
    sampler = build_bt_sampler(da)
    area = da.attrs["area"]
    to_lonlat = Transformer.from_crs(area.crs, "EPSG:4326", always_xy=True)
    sample_points = [
        (2750, 2750),
        (2750, 1000),
        (1000, 2750),
        (1500, 1500),
        (4000, 4000),
    ]
    errors: list[float] = []
    for iy, ix in sample_points:
        value = float(da.values[iy, ix])
        if not math.isfinite(value):
            continue
        x = float(da.x.values[ix])
        y = float(da.y.values[iy])
        lon, lat = to_lonlat.transform(x, y)
        sampled = float(sampler(np.array([[lon]], dtype=np.float64), np.array([[lat]], dtype=np.float64))[0, 0])
        errors.append(abs(sampled - value))
    if not errors:
        raise ValueError("No finite verification points were available")
    return max(errors), float(sum(errors) / len(errors))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tile_dir", type=Path, help="Directory containing Himawari ISatSS M1C13 tile NetCDF files")
    parser.add_argument("--write-netcdf", type=Path, help="Optional path to write the stitched dataset as NetCDF")
    parser.add_argument("--verify-area", action="store_true", help="Build da.attrs['area'] and verify bt_sampler round-trip")
    parser.add_argument("--observer-lat", type=float, help="If set with --observer-lon, stitch only the locally selected tiles needed for this observer")
    parser.add_argument("--observer-lon", type=float, help="If set with --observer-lat, stitch only the locally selected tiles needed for this observer")
    parser.add_argument("--cloud-shell-km", type=float, default=6376.0, help="Cloud shell radius in km for observer-based tile selection")
    parser.add_argument("--azimuth-samples", type=int, default=1440, help="Boundary sample count for observer-based tile selection")
    parser.add_argument("--margin-tiles", type=int, default=1, help="Extra tile ring for observer-based tile selection")
    args = parser.parse_args()

    use_partial = (args.observer_lat is not None) or (args.observer_lon is not None)
    if args.observer_lat is None and args.observer_lon is None:
        tile_paths = _iter_tile_paths(args.tile_dir)
        source_label = str(args.tile_dir)
    elif args.observer_lat is not None and args.observer_lon is not None:
        tile_paths = _select_tile_paths_for_observer(
            args.tile_dir,
            observer_lat=float(args.observer_lat),
            observer_lon=float(args.observer_lon),
            cloud_shell_km=float(args.cloud_shell_km),
            azimuth_samples=int(args.azimuth_samples),
            margin_tiles=int(args.margin_tiles),
        )
        source_label = f"{args.tile_dir} [observer lat={args.observer_lat}, lon={args.observer_lon}]"
    else:
        raise SystemExit("--observer-lat and --observer-lon must be provided together")

    merged = stitch_tiles_from_paths(tile_paths, source_label=source_label)
    try:
        working = attach_area_to_dataset(merged)
        bt = working[DATA_VAR]
        area = bt.attrs["area"]
        mask = merged["tile_coverage_mask"].values.astype(bool)
        finite = np.isfinite(bt.values)
        print(f"tile_dir={args.tile_dir}")
        if use_partial:
            print(f"selected_tile_count={len(tile_paths)}")
        print(f"shape={bt.shape}")
        print(f"tile_count={merged.attrs['stitched_from_tiles']}")
        print(f"coverage_fraction={float(mask.mean()):.4f}")
        print(f"finite_fraction={float(finite.mean()):.4f}")
        print(f"bt_min={float(np.nanmin(bt.values)):.6f}")
        print(f"bt_max={float(np.nanmax(bt.values)):.6f}")
        print(f"x_range=({float(bt.x.values[0]):.6f}, {float(bt.x.values[-1]):.6f})")
        print(f"y_range=({float(bt.y.values[0]):.6f}, {float(bt.y.values[-1]):.6f})")
        print(f"area_shape={area.shape}")
        print(f"area_extent={tuple(float(v) for v in area.area_extent)}")
        print(f"area_crs={area.crs.to_proj4()}")
        if args.verify_area:
            max_err, mean_err = verify_sampler_roundtrip(merged)
            print(f"sampler_roundtrip_max_abs_err={max_err:.6f}")
            print(f"sampler_roundtrip_mean_abs_err={mean_err:.6f}")
        if args.write_netcdf is not None:
            serializable = working.copy(deep=False)
            serializable[DATA_VAR] = serializable[DATA_VAR].copy(deep=False)
            data_attrs = dict(serializable[DATA_VAR].attrs)
            data_attrs.pop("area", None)
            serializable[DATA_VAR].attrs = data_attrs
            serializable.to_netcdf(args.write_netcdf)
            print(f"wrote={args.write_netcdf}")
    finally:
        merged.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
