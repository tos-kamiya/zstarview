"""Trial clouddisc package for satpy-replacement investigation."""
