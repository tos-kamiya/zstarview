"""Trial satellite providers."""
