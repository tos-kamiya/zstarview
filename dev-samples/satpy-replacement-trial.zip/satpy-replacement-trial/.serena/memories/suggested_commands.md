# Suggested Commands
- List files: `ls -la`
- Read notes: `sed -n '1,220p' README.md`, `sed -n '1,260p' HANDOFF.md`
- Inspect downloaded NetCDF tile with parent venv: `uv run -p ../.venv/bin/python - <<'PY' ... PY`
- Expected next-step tooling: xarray-based inspection of cached ISatSS files under `~/.cache/zstarview/hima_isatss/...`
