# Style And Completion
- This subproject currently contains notes, not code.
- Follow parent repo conventions from AGENTS.md when code is added: Python 3.10+, PEP 8, snake_case, tests under tests/.
- When a task is completed, summarize findings and preserve separation between user-facing spec, internal design, and implementation history if docs are added.
