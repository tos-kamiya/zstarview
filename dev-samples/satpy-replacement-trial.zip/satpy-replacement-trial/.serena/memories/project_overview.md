# satpy-replacement-trial
- Purpose: small investigation workspace for replacing the satpy-based Himawari ISatSS ingestion path used by the parent zstarview project.
- Current state: top-level content is documentation/handoff only; no implementation source tree exists in this subproject yet.
- Key documents: README.md for goal/scope; HANDOFF.md for findings, constraints, and next commands.
- Tech stack expected for investigation: Python with xarray/numpy via uv and the parent repo virtualenv.
