# Handoff

## Why this directory exists

The main `zstarview` repo hit a natural boundary: Himawari `ISatSS` data is not
drop-in compatible with the assumptions used by the current `satpy`-based code.
This work is better handled as a small, separate investigation before any
further integration into the app.

## Current findings

- The previous `HSD -> ISatSS` fallback in zstarview was changed experimentally
  to `ISatSS`-only.
- Initial assumption was wrong:
  - ISatSS under `AHI-L2-FLDK-ISatSS/...` is not exposed as a single `B13`
    NetCDF file per timeslot.
- Observed S3 layout for `noaa-himawari9`:
  - Prefix example:
    `AHI-L2-FLDK-ISatSS/2026/03/21/0600/`
  - `total_keys=1408`
  - Band-like breakdown from filenames seen:
    - `B11`: 792 files
    - `B12`: 528 files
    - `B14`: 88 files
  - The C13-related files are named with `M1C13`, not `B13`.
  - Example filenames:
    - `OR_HFD-020-B12-M1C13-T001_GH9_s20260800600000_c20260800608110.nc`
    - `OR_HFD-020-B12-M1C13-T088_GH9_s20260800600000_c20260800620360.nc`
- Filtering by `B13` returned zero matches.
- Filtering by `M1C13` found 88 files for a timeslot.
- Download of those tiles succeeded.
- `satpy` then failed to open them with `reader="ahi_l2_nc"`:
  - `No filenames found for reader: ahi_l2_nc`
  - `Don't know how to open the following files: {...}`

## Implication

This is not just a search-pattern bug anymore. For Himawari ISatSS:

- the naming/layout differs from the original assumption,
- the files appear tiled,
- and the current Satpy reader path used by zstarview does not recognize them.

That means the next step is direct inspection of the NetCDF contents with
`xarray`, not more guessing inside the app.

## Important constraint from zstarview

zstarview does **not** primarily need a finished image file for cloud rendering.
What the main app needs is a numerically usable source field that can be
sampled onto the observer view.

Concretely:

- `zstarview.clouddisc.core.CloudDisc` expects source data as an
  `xarray.DataArray`.
- The downstream sampler in
  `src/zstarview/clouddisc/sampling/bt_sampler.py`
  does reprojection/interpolation from satellite space into the app's observer
  view.
- In the current implementation, that sampler expects projection metadata via
  `da.attrs["area"]` from Satpy.

So the replacement target is not:

- "produce a PNG" or
- "decode tiles into a display-ready image"

The replacement target is:

- produce a merged `xarray.DataArray` for the C13 brightness-temperature-like
  field, plus enough projection/geolocation metadata to support sampling.

If the trial only yields a stitched image, that is insufficient for direct
integration into zstarview's current cloud pipeline.

## Suggested first commands

Run from this directory or the repo root.

Use a real downloaded file under:

`/home/toshihiro/.cache/zstarview/hima_isatss/noaa-himawari9/AHI-L2-FLDK-ISatSS/...`

Better first inspection:

```bash
uv run -p ../.venv/bin/python - <<'PY'
import xarray as xr
path = "/home/toshihiro/.cache/zstarview/hima_isatss/noaa-himawari9/AHI-L2-FLDK-ISatSS/2026/03/21/0610/OR_HFD-020-B12-M1C13-T001_GH9_s20260800610000_c20260800620360.nc"
ds = xr.open_dataset(path)
print(ds)
print(ds.data_vars)
print(ds.coords)
print(ds.attrs)
PY
```

Then compare multiple tiles:

```bash
uv run -p ../.venv/bin/python - <<'PY'
import xarray as xr
from pathlib import Path
base = Path("/home/toshihiro/.cache/zstarview/hima_isatss/noaa-himawari9/AHI-L2-FLDK-ISatSS/2026/03/21/0610")
for path in sorted(base.glob("*M1C13*.nc"))[:3]:
    ds = xr.open_dataset(path)
    print(path.name)
    print(ds.dims)
    print(ds.attrs)
    print(list(ds.data_vars))
    print()
PY
```

## What to answer next

The next Codex session should answer these questions first:

1. Which variable in the `M1C13` tile contains the usable image data?
2. Is it already brightness temperature, or another quantity?
3. How do tile indices `T001..T088` map spatially?
4. What metadata is available for projection/geolocation?
5. Can the tiles be stitched with only `xarray`/`numpy`, or is additional
   geospatial metadata handling required?

## Main-project caution

The main repo currently contains experimental Himawari changes. Treat them as
temporary until this trial produces a concrete reader approach.
